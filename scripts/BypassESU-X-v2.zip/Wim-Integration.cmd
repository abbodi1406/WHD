@setlocal DisableDelayedExpansion
@echo off
set "_args=%*"
set "_elv="
if not defined _args goto :NoProgArgs
if "%~1"=="" set "_args="&goto :NoProgArgs
set _args=%_args:"=%
for %%A in (%_args%) do (
if /i "%%A"=="-wow" (set _rel1=1) else if /i "%%A"=="-arm" (set _rel2=1) else if /i "%%A"=="-su" (set _elv=1)
)
:NoProgArgs
set "_cmdf=%~f0"
if exist "%SystemRoot%\Sysnative\cmd.exe" if not defined _rel1 (
setlocal EnableDelayedExpansion
start %SystemRoot%\Sysnative\cmd.exe /c ""!_cmdf!" -wow %*"
exit /b
)
if exist "%SystemRoot%\SysArm32\cmd.exe" if /i %PROCESSOR_ARCHITECTURE%==AMD64 if not defined _rel2 (
setlocal EnableDelayedExpansion
start %SystemRoot%\SysArm32\cmd.exe /c ""!_cmdf!" -arm %*"
exit /b
)
set "SysPath=%SystemRoot%\System32"
set "Path=%SystemRoot%\System32;%SystemRoot%;%SystemRoot%\System32\Wbem;%SystemRoot%\System32\WindowsPowerShell\v1.0\"
if exist "%SystemRoot%\Sysnative\reg.exe" (
set "SysPath=%SystemRoot%\Sysnative"
set "Path=%SystemRoot%\Sysnative;%SystemRoot%;%SystemRoot%\Sysnative\Wbem;%SystemRoot%\Sysnative\WindowsPowerShell\v1.0\;%Path%"
)
set "_Nul1=1>nul"
set "_Nul2=2>nul"
set "_Nul6=2^>nul"
set "_Nul3=1>nul 2>nul"
set "_err===== ERROR ===="
reg query HKU\S-1-5-19 %_Nul3% || goto :E_Admin

set "_psc=powershell -nop -c"
set "_Wnn=HKLM\wSOFTWARE\Microsoft\Windows\CurrentVersion\SideBySide\Winners"
set "_Cmp=HKLM\wCOMPONENTS\DerivedData\Components"
set "_Pkt=31bf3856ad364e35"
set "_OurVer=25.10.0.0"
set "_EsuCmp=microsoft-windows-s..edsecurityupdatesai"
set "_EsuIdn=Microsoft-Windows-Security-SPP-Component-ExtendedSecurityUpdatesAI"

set "_work=%~dp0"
set "_work=%_work:~0,-1%"
setlocal EnableDelayedExpansion
pushd "!_work!"
if not exist "bin\" goto :E_DLL
for %%# in (
wimlib-imagex.exe
libwim-15.dll
wimfile.cmd
) do (
if not exist "bin\%%~#" (set "_file=%%~nx#"&goto :E_DLL)
)

:Begin
set _wim=0
if exist "*.wim" (for /f "tokens=* delims=" %%# in ('dir /b /a:-d "*.wim"') do (call set /a _wim+=1))
if %_wim% equ 1 (
for /f "tokens=* delims=" %%# in ('dir /b /a:-d "*.wim"') do set "target=!_work!\%%~nx#"
goto :CheckWIM
)
set _wim=0
set _img=0
@cls
echo.
echo Enter the target path:
echo - WIM file ^(not mounted^)
echo - Mounted directory, offline image drive letter
echo.
set /p target=
if not defined target exit /b
set "target=%target:"=%"
if "%target:~-1%"=="\" set "target=%target:~0,-1%"
if /i "%target%"=="%SystemDrive%" exit /b

if /i "%target:~-4%"==".wim" (
if exist "%target%" set _wim=1
) else (
if exist "%target%\Windows\regedit.exe" set _img=1
)

if %_wim% equ 0 if %_img% equ 0 (
echo.
echo %_err%
echo Specified location is not valid
goto :TheEnd
)

if %_wim% equ 1 goto :CheckWIM

set _build=1
for /f "tokens=3 delims=." %%# in ('dir /b /ad "%target%\Windows\Servicing\Version\1*" %_Nul6%') do set _build=%%#
if %_build% lss 14393 goto :E_Win
if %_build% gtr 19045 goto :E_Win

@cls
echo.
echo ____________________________________________________________
echo.
echo Checking . . .
echo.

set _pwsh=1
for %%# in (powershell.exe) do @if "%%~$PATH:#"=="" set _pwsh=0
cmd /c "%_psc% "$ExecutionContext.SessionState.LanguageMode"" | find /i "FullLanguage" 1>nul || (set _pwsh=0)
if %_pwsh% equ 0 goto :E_PWS

set "_Wdr=%target%\Windows"
set "_Mnf=%_Wdr%\WinSxS\Manifests"
set "SysPath=%_Wdr%\System32"
if exist "%_Wdr%\Servicing\Packages\*~arm64~~*.mum" (
set "xBT=arm64"
set "_EsuCom=arm64_%_EsuCmp%_%_Pkt%_%_OurVer%_none_eeb9e0b00f513fbe"
set "_EsuKey=%_Wnn%\arm64_%_EsuCmp%_%_Pkt%_none_0e1ac5e1d0e42392"
) else if exist "%_Wdr%\Servicing\Packages\*~amd64~~*.mum" (
set "xBT=amd64"
set "_EsuCom=amd64_%_EsuCmp%_%_Pkt%_%_OurVer%_none_eeb9d8760f514b22"
set "_EsuKey=%_Wnn%\amd64_%_EsuCmp%_%_Pkt%_none_0e1abda7d0e42ef6"
) else (
set "xBT=x86"
set "_EsuCom=x86_%_EsuCmp%_%_Pkt%_%_OurVer%_none_929b3cf256f3d9ec"
set "_EsuKey=%_Wnn%\x86_%_EsuCmp%_%_Pkt%_none_b1fc22241886bdc0"
)
for /f "tokens=4,5,6 delims=_" %%H in ('dir /b "%_Mnf%\%xBT%_microsoft-windows-foundation_*.manifest"') do set "_Fnd=microsoft-w..-foundation_%_Pkt%_%%H_%%~nJ"

set _WinPE=0
if exist "%_Wdr%\Servicing\Packages\*WinPE-LanguagePack*.mum" set _WinPE=1

reg load HKLM\wSOFTWARE "%SysPath%\Config\SOFTWARE" %_Nul3%
set _EsuPkg=0
if exist "%_Mnf%\%_EsuCom%.manifest" (
reg query "%_EsuKey%" /ve %_Nul2% | find /i "%_OurVer:~0,5%" %_Nul1% && (
  reg query "%_EsuKey%\%_OurVer:~0,5%" /ve %_Nul2% | find /i "%_OurVer%" %_Nul1% && set _EsuPkg=1
  )
)

set _EsuUpdt=0
set "_EsuMajor="
set "_EsuWinner="
if not exist "%_Mnf%\%xBT%_%_EsuCmp%*.manifest" goto :proceed
reg query "%_EsuKey%" %_Nul3% || goto :proceed
reg load HKLM\wCOMPONENTS "%SysPath%\config\COMPONENTS" %_Nul3%
reg query "%_Cmp%" /f "%xBT%_%_EsuCmp%_*" /k %_Nul2% | find /i "edsecurityupdatesai" %_Nul1% || goto :proceed
for /f "tokens=4 delims=_" %%# in ('dir /b "%_Mnf%\%xBT%_%_EsuCmp%*.manifest"') do (
set "_ChkVer=%%#"&call :checkver
)
goto :proceed

:checkver
if "%_ChkVer%"=="%_OurVer%" exit /b
reg query "%_Cmp%" /f "%xBT%_%_EsuCmp%_%_Pkt%_%_ChkVer%_*" /k %_Nul2% | find /i "%_ChkVer%" %_Nul1% || exit /b
reg query "%_EsuKey%\%_ChkVer:~0,4%" /t REG_BINARY %_Nul2% | find /i "%_ChkVer%" %_Nul1% || exit /b
set _EsuUpdt=1
set "_EsuMajor=%_ChkVer:~0,4%"
set "_EsuWinner=%_ChkVer%"
exit /b

:proceed
reg unload HKLM\wSOFTWARE %_Nul3%
reg unload HKLM\wCOMPONENTS %_Nul3%
@title BypassESU X v1

:MainMenu
set _elr=0
@cls
echo ____________________________________________________________
echo.
if %_EsuPkg% equ 0 (
echo [1] Integrate ESU Suppressor
echo.
)
if %_EsuPkg% equ 1 (
echo [2] Remove ESU Suppressor
echo.
)
echo [9] Exit
echo.
echo ____________________________________________________________
echo.
choice /C 129 /N /M "Choose a menu option: "
set _elr=%errorlevel%
if %_elr%==3 goto :eof
if %_elr%==2 if %_EsuPkg% equ 1 (goto :Uninstall)
if %_elr%==1 if %_EsuPkg% equ 0 (goto :imgESU)
goto :MainMenu

:imgESU
@cls
echo.
echo ____________________________________________________________
echo.
echo Integrating ESU Suppressor . . .
echo.

if not exist "%SystemRoot%\Temp\" mkdir "%SystemRoot%\Temp"
if not exist "%SystemRoot%\Temp\%_EsuCom%.manifest" (
(echo ^<?xml version="1.0" encoding="UTF-8" standalone="yes"?^>
echo ^<assembly xmlns="urn:schemas-microsoft-com:asm.v3" manifestVersion="1.0" copyright="Copyright (c) Microsoft Corporation. All Rights Reserved."^>
echo   ^<assemblyIdentity name="%_EsuIdn%" version="%_OurVer%" processorArchitecture="%xBT%" language="neutral" buildType="release" publicKeyToken="%_Pkt%" versionScope="nonSxS" /^>
echo ^</assembly^>)>"%SystemRoot%\Temp\%_EsuCom%.manifest"
)
if not exist "%SystemRoot%\Temp\%_EsuCom%.manifest" (
goto :E_Fail
)
set "_InIdt="
set "_psin=%_EsuIdn%, Culture=neutral, Version=%_OurVer%, PublicKeyToken=%_Pkt%, ProcessorArchitecture=%xBT%, versionScope=NonSxS"
for /f "tokens=* delims=" %%# in ('%_psc% "[BitConverter]::ToString([Text.Encoding]::ASCII.GetBytes($env:_psin)) -replace '-'"') do set "_InIdt=%%#"
if not defined _InIdt goto :E_Fail
set "_InHsh="
for /f "tokens=* delims=" %%# in ('%_psc% "[BitConverter]::ToString([Security.Cryptography.SHA256]::Create().ComputeHash(([IO.StreamReader]'%SystemRoot%\Temp\%_EsuCom%.manifest').BaseStream)) -replace '-'"') do set "_InHsh=%%#"
if not defined _InHsh goto :E_Fail

call :IMGt %_Nul3%
if not defined _InIdt goto :E_Fail
echo.
echo Done.
goto :TheEnd

:IMGt
icacls "%_Mnf%" /save "%SystemRoot%\Temp\acl.txt"
takeown /f "%_Mnf%" /A
icacls "%_Mnf%" /grant:r "*S-1-5-32-544:(OI)(CI)(F)"
copy /y "%SystemRoot%\Temp\%_EsuCom%.manifest" "%_Mnf%\"
icacls "%_Mnf%" /setowner *S-1-5-80-956008885-3418522649-1831038044-1853292631-2271478464
icacls "%_Wdr%\WinSxS" /restore "%SystemRoot%\Temp\acl.txt"
del /f /q "%SystemRoot%\Temp\acl.txt"
if not exist "%_Mnf%\%_EsuCom%.manifest" (
set "_InIdt="
exit /b
)
reg load HKLM\wCOMPONENTS "%SysPath%\config\COMPONENTS"
reg load HKLM\wSOFTWARE "%SysPath%\config\SOFTWARE"
reg delete "%_Cmp%\%_EsuCom%" /f
reg add "%_Cmp%\%_EsuCom%" /f /v "c^!%_Fnd%" /t REG_BINARY /d ""
reg add "%_Cmp%\%_EsuCom%" /f /v identity /t REG_BINARY /d "%_InIdt%"
reg add "%_Cmp%\%_EsuCom%" /f /v S256H /t REG_BINARY /d "%_InHsh%"
reg add "%_Cmp%\%_EsuCom%" /f /v CF /t REG_DWORD /d "64"
reg add "%_EsuKey%" /f /ve /d %_OurVer:~0,5%
reg add "%_EsuKey%\%_OurVer:~0,5%" /f /ve /d %_OurVer%
reg add "%_EsuKey%\%_OurVer:~0,5%" /f /v %_OurVer% /t REG_BINARY /d 01
reg unload HKLM\wCOMPONENTS
reg unload HKLM\wSOFTWARE
exit /b

:Uninstall
@cls
echo.
echo ____________________________________________________________
echo.
echo Removing ESU Suppressor . . .
echo.
call :RemoveManual %_Nul3%
echo.
echo Done.
goto :TheEnd

:RemoveManual
reg load HKLM\wCOMPONENTS "%SysPath%\Config\COMPONENTS"
reg load HKLM\wSOFTWARE "%SysPath%\Config\SOFTWARE"
reg delete "%_Cmp%\%_EsuCom%" /f
reg delete "%_EsuKey%\%_OurVer:~0,5%" /f /v %_OurVer%
if exist "%_Mnf%\%_EsuCom%.manifest" (
takeown /f "%_Mnf%\%_EsuCom%.manifest" /A
icacls "%_Mnf%\%_EsuCom%.manifest" /grant:r "*S-1-5-32-544:(OI)(CI)(F)"
del /f /q "%_Mnf%\%_EsuCom%.manifest"
)
if not exist "%_Mnf%\*_%_EsuCmp%*.manifest" (
reg delete "%_EsuKey%" /f
) else (
if defined _EsuWinner (
  reg add "%_EsuKey%" /f /ve /d "%_EsuMajor%"
  reg add "%_EsuKey%\%_EsuMajor%" /f /ve /d "%_EsuWinner%"
  ) else (
  reg delete "%_EsuKey%" /f
  )
)
for /f "tokens=* delims=" %%# in ('reg query HKLM\wCOMPONENTS\DerivedData\VersionedIndex %_Nul6% ^| findstr /i VersionedIndex') do reg delete "%%#" /f
reg unload HKLM\wCOMPONENTS
reg unload HKLM\wSOFTWARE
exit /b

:CheckWIM
cd bin\
call wimfile.cmd "%target%"
goto :TheEnd

:E_Admin
echo %_err%
echo This script requires administrator privileges.
goto :TheEnd

:E_Win
echo %_err%
echo Specified offline image build is not supported.
goto :TheEnd

:E_PWS
echo %_err%
echo Windows PowerShell is not detected or not working correctly.
echo It is required for this script to work.
goto :TheEnd

:E_Fail
echo %_err%
echo Operation failed.
echo Verify that Windows Powershell is working correctly.
echo Temporary disable Defender or Antivirus protection.
goto :TheEnd

:E_DLL
echo %_err%
echo Required file bin\%_file% is missing.
goto :TheEnd

:TheEnd
if exist "%SystemRoot%\Temp\*.manifest" (
del /f /q "%SystemRoot%\Temp\*.manifest" %_Nul3%
)
echo.
echo Press 9 or q to exit.
choice /c 9Q /n
if errorlevel 1 (goto :eof) else (rem.)
