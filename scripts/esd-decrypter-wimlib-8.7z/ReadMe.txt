# Info #

An automated script to handle microsoft's original ESD file (encrypted or decrypted),
to ease converting it into an usable state (ISO / WIM / decrypted ESD).

===============================================================================

# How To Use #

- It's recommended to temporary disable AV or protection program so it doesn't interfere with the process.

- Make sure the ESD file is not read-only or blocked.

- Extract this package contents to a folder with simple path (example: C:\ESD).

- You have many ways to start the process:
1) Copy/Move ESD file to the same folder besides the script, then open the script

2) Drag & drop the file on decrypt.cmd

3) Directly open decrypt.cmd and you will be prompted to enter the ESD file path

4) Open Command Prompt in the current directory, and Execute: decrypt ESDfilename
this method allow the present of several ESD files in the current directory, or using ESD from another location.
examples:
decrypt C:\RecoveryImage\install.esd
decrypt 9926.0.150119-1648.fbl_awesome1501_clientpro_ret_x86fre_en-us.esd
decrypt C:\Data\Programs\ISO\ESD\ir4_cpra_x64frer_en-us.esd

- If all goes well, you will have 4 options to proceed:

1 - Create Full ISO with Standard install.wim
this will substantially convert ESD file to a regular ISO distribution that contains standard install.wim file

2 - Create Full ISO with Compressed install.esd
this is similar to the first, but it will use and contain highly compressed install.esd file

3 - Create Standard install.wim
this will create a single install.wim file, which you can use with any ISO you already have for the same product and same version
or to use it for manual apply using dism/wimlib

4 - Create Compressed install.esd
this is similar to the third, but it will create install.esd file, which can be used just like install.wim

5 - Decrypt ESD file only
to just decrypt the ESD file

- Note:
if the ESD file is encrypted, it won't be backed up before decryption
to change that and have ESD backed-up, press 9 before starting the other options

if the ESD file is already decrypted, you will get an option to view its info

===============================================================================

# Credits #

qad - decryption program
Eric Biggers - wimlib
murphy78 - original script
Chris123NT, MrMagic, mohitbajaj143 - RSA cryptokey
nosferati87, NiFu, s1ave77, and any other MDL forums members contributed in the ESD project
