# .NET 4.8 Installer for Windows 10 Version 1507/1511

## Requirements

- .NET Framework 4.8 for Windows 10 Version 1607:

x64  
http://wsus.ds.download.windowsupdate.com/c/msdownload/update/software/ftpk/2020/01/windows10.0-kb4486129-x64_0b61d9a03db731562e0a0b49383342a4d8cbe36a.msu

x86  
http://wsus.ds.download.windowsupdate.com/c/msdownload/update/software/ftpk/2020/01/windows10.0-kb4486129-x86_d38ebe43baeabaef927675c7ff2295843f19a077.msu

- Download and place the msu file in the same folder next to KB4486129-Offline.cmd

- To install the package for already installed system, you nend either of:

Another installed Host OS: Windows 10, or Windows 8.1/7 with Windows ADK

Or, create custom Windows 10 WinPE image with Windows PowerShell support  
https://docs.microsoft.com/en-us/windows-hardware/manufacture/desktop/winpe-adding-powershell-support-to-windows-pe

- To install the package for install.wim image:

Host OS: Windows 10, or Windows 8.1/7 with Windows ADK

## How to update already installed system

- reboot to the other Windows OS, or boot the custom WinPE image

- run KB4486129-Offline.cmd as administrator

- enter the correct drive letter for the target system, then press Enter

you can run and use notepad in WinPE as explorer to find the correct drive

## How to update install.wim image

- manually mount the needed index of install.wim using DISM.exe tool

- run KB4486129-Offline.cmd as administrator

- enter the mount directory path, then press Enter

- manually unmount install.wim and commit changes
