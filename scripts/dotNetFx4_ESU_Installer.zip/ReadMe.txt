# dotNetFx4 ESU Installer

* A batch script to install .NET 4.x ESU updates for Windows 7 and Windows Server 2008 R2.

* Those updates include:  
.NET 4.8 (NDP48)  
.NET 4.6, 4.6.1, 4.6.2, 4.7, 4.7.1, 4.7.2 (NDP47)  
.NET 4.5.2 (NDP45)

## How to Use

* Make sure that no Windows Installer (MSI) operations are running, reboot the system if needed

* Download the correct NDP update, based on your installed .NET 4.x version and OS architecture

https://devblogs.microsoft.com/dotnet/

* Extract dotNetFx4_ESU_Installer.cmd a folder with simple path

* Copy or move NDP update exe file(s) to the same folder

* Right-click on dotNetFx4_ESU_Installer.cmd and "Run as administrator"  

## Credits

* vinzf  
* abbodi1406
