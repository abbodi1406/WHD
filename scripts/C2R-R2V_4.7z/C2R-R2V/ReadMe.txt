- Convert Office 2016/2019 ClickToRun installation licensing from Retail to Volume
which then can be activated easily using various KMS solutions

- All current Office licenses will be cleaned up
then, proper Volume licenses will be installed based on detected office products

- Activated free preview licenses for Office 2019 will be preserved

- "Mondo" Suite cover all products, if detected, only its licenses will be installed

- "O365ProPlus" Suite will be converted with Mondo licenses

- "Professional" Suite will be converted with ProPlus licenses

- If main products SKUs are detected, separate sub-apps licenses will not be installed to avoid duplication

SKUs : ProPlus, Professional, Standard, Visio, Project
Apps : Access, Excel, Onenote, Outlook, Powerpoint, Publisher, SkypeForBusiness, Word

O365ProPlus/ProPlus cover all sub-apps
Professional cover all sub-apps except SkypeForBusiness
Standard cover all sub-apps except Access, SkypeForBusiness

- Note: This is not an activator, just a licensing converter