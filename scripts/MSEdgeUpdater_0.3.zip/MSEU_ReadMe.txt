# Microsoft Edge Updater for Windows 10 Enterprise LTSC / LTSB

* Windows 10 Enterprise 2019 LTSC / LTSC N (build 17763)

* Windows 10 Enterprise 2016 LTSB / LTSB N (build 14393)

# How To:

* Important: first, install Latest Cumulative Update (LCU) normally

* Download LCU msu or cab file, and place it next to MSEU.cmd

* To update current online OS:  
- leave set "target=" as blank  
- Run MSEU.cmd as administrator

* To update offline image:  
- you have to manually mount install.wim  
- make sure MS Edge is already integrated/installed  
- edit MSEU.cmd and set the correct mount directory path, or offline image driver letter  
- example: set "target=C:\Mount"  
- Run MSEU.cmd as administrator  
- manually unmount install.wim and commit changes

* Repeat the same steps order with each new LCU

# Credits:

@Mouri_Naruto - NSudoC.exe
https://forums.mydigitallife.net/threads/59268

@Compo - bat/vbs/xml inside Batch Script
https://forums.mydigitallife.net/posts/1221231

@BAU - Compressed2TXT res85 ascii encoder
https://github.com/AveYo/Compressed2TXT

@abbodi1406 - MSEU.cmd
