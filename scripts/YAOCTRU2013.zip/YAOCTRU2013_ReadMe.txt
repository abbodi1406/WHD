# Office 2013 Click To Run URL Generator

## Intro

* A command line script to generate download links for Office 2013 Click To Run installation source files

* Office C2R source files are universal, and contain all possible products, any SKU can be installed from the same source  

* To install Office 2013 C2R, you can use the official Office Deployment Tool  
https://www.microsoft.com/en-sa/download/details.aspx?id=36778

______________________________

## How To

* Run the script normally with a double-click

* Choose desired Office Bitness (architecture)

* Choose a Language by entering its option number (for the first 9 languages, you can enter the number without leading zero 0)

* Choose Office source type to download: Full or Language Pack

* Finally, choose the output type: 

1. Aria2 script (aria2c.exe)  
https://aria2.github.io/

2. Wget script (wget.exe)  
https://eternallybored.org/misc/wget/

3. cURL script (curl.exe)  
https://skanthak.homepage.t-online.de/curl.html
https://curl.se/windows/

Windows 11 and Windows 10 version 1803 or later already contain curl.exe by default

4. Text file  
plain text file with links, to be used with any Download Manager program, or through the browser
additionally, an "arrange" batch file will be created to help to organize files in a proper hierarchy

______________________________

## Output Files

* Naming scheme: Version_Bitness_Lang_SourceType_Channel_OutputType

examples:  
15.0.5603.1000_x86x64_en-US_2013_aria2.bat  
15.0.5197.1000_x64_fr-FR_2013_wget.bat  

* aria2c.exe, wget.exe or curl.exe must be placed next to the download scripts,  
or in the system path directories, C:\Windows or C:\Windows\System32

* Aria2, Wget and cURL scripts will properly download and arrange the files under "C2R_2013" folder in the same directory they are executed in  
where xxx represent the channel name, for example: C2R_Monthly

* Aria2, Wget and cURL scripts allow limiting the download speed (bandwidth)  
to do so, edit the scripts prior downloading and change speedLimit

* Aria2 script allows changing the parallel (concurrent) downloads  
to do so, edit the script prior downloading and change set "parallel=1"

______________________________

## Credits

* Creator       : @abbodi1406  
* Special Thanks: @Windows_Addict
