- Convert Office 2013 ClickToRun installation licensing from Retail to Volume
which then can be activated easily using various KMS solutions

- This is not an activator, just a licensing converter

- All current Office licenses will be cleaned up
then, proper Volume licenses will be installed based on detected office products

- Office Mondo suite cover all products, if detected, only its licenses will be installed

- Office 365 products will be converted with Mondo licenses  
also, corresponding Office 365 Retail Grace Key will be installed

- Office Professional suite will be converted with Office ProPlus licenses

- Office HomeBusiness/HomeStudent suites will be converted with Office Standard licenses

- If Office 2019 RTM licenses are not detected, Office 2016 licenses will be used instead

- If main products SKUs are detected, separate apps licenses will not be installed to avoid duplication

SKUs:
O365ProPlus, O365SmallBusPrem, O365HomePrem, O365Business  
ProPlus, Professional, Standard, HomeBusiness, HomeStudent, Visio, Project

Apps:
Access, Excel, InfoPath, Onenote, Outlook, PowerPoint, Publisher, SkypeForBusiness, Word

O365ProPlus, O365SmallBusPrem, ProPlus cover all apps  
O365HomePrem, Professional cover all apps except SkypeForBusiness  
O365Business, Standard cover all apps except Access, SkypeForBusiness
