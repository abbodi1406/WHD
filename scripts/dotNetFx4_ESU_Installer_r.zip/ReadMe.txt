# dotNetFx4 ESU Installer v2

## Info

* A command line script to install .NET 4.x ESU updates manually for Windows 7 and Windows Server 2008 R2.

* Those updates include:  
NDP48: .NET 4.8  
NDP47: .NET 4.6, 4.6.1, 4.6.2, 4.7, 4.7.1, 4.7.2  
NDP45: .NET 4.5.2

* The script require custom slc.dll redirection to bypass the ESU validation.

* The script will remove dotNetFx4 ESU Bypass hook if detected.

## How to Use

* Download the correct NDP updates exe files, based on your installed .NET 4.x version and OS architecture

https://devblogs.microsoft.com/dotnet/

* Make sure there are no running or pending Windows Installer (MSI) operations, reboot the system if needed

* Extract the zip file contents to a folder with simple path

* Copy or move NDP updates exe files to the same folder

* Right-click on dotNetFx4_ESU_Installer.cmd and "Run as administrator"  

## Credits

* IMI Kurwica  
* abbodi1406
