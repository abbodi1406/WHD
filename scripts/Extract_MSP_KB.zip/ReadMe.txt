- extract and prepare Office msp files, it will rename them uniquely per KB number
mainly for Office 2010

- variables:
"EXEFOL" the path to parent office updates folder
"MSPFOL" extracted MSP files path, default is 'MSPs' folder next to the script
"LANG" the locale to be kept. Leaving it empty will keep all locales.
"PROOFLANG" the companion proofing languages. Leaving it empty will only keep the above locale patch.
https://technet.microsoft.com/en-us/library/ee942198(office.14).aspx

- afterwards, manually delete msp files that have newer similar files
example:
z_word2010-kb2965313-x86.msp <- delete
z_word2010-kb3128034-x86.msp <- keep
