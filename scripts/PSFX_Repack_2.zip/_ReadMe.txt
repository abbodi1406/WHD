# PSFX v2 Repack

## Info

- Starting build 21382, Microsoft provide Latest Cumulatie Update (LCU) via UUP as a new PSFX v2 format

- It consist of cab file that contain the update manifests, and psf file that contain the raw payload files

- To use the new format for DISM update operation, it's required to extract (generate) the actual payload files first

- Afterward, you can use the extracted folder path with DISM, or compress the folder into a full cab file

- repack_psfx command script automate the process and repackage the psf/cab files into a full cab file

## Usage

- Extract this package zip file to a folder with a simple path

- Copy or move the psf/cab files next to the script, then run repack_psfx.cmd

- Or from command prompt, run repack_psfx.cmd and provide path to the folder containing psf/cab files

example:  
repack_psfx.cmd E:\Downloads\uup-converter\UUPs

- The result file will be located in the same folder (current or provided)  
and it will have the same name of the original cab file, appended with -full_psfx

example:  
windows10.0-kb5004564-arm64-full_psfx.cab

## Notice

- The script do not require administrator privileges  
however, if you get Access Denied errors, run it as administrator

## Credits

- th1r5bvn23 - PSFExtractor  
https://www.betaworld.org/

- Melinda Bellemore - SxSExpand  
https://forums.mydigitallife.net/members/superbubble.250156/
