# Microsoft Edge Updater for Windows 10 Enterprise LTSC / LTSB

- Windows 10 Enterprise 2019 LTSC / LTSC N (build 17763)

- Windows 10 Enterprise 2016 LTSB / LTSB N (build 14393)

# How To:

- Important: first, install Latest Cumulative Update (LCU) normally (through WindowsUpdate or manually)

- Download LCU msu or cab file, and place it next to MSEU.cmd

- Run MSEU.cmd as administrator

- Repeat the same steps order with each new LCU

# Credits:

@Mouri_Naruto - NSudoC.exe
https://forums.mydigitallife.net/threads/59268

@Compo - bat/vbs/xml inside Batch Script
https://forums.mydigitallife.net/posts/1221231

@BAU - Compressed2TXT res85 ascii encoder
https://github.com/AveYo/Compressed2TXT

@abbodi1406 - MSEU.cmd
