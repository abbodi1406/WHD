# BypassESU X

* A project to install Extended Security Updates for:  
Windows 10 Versions 22H2-2004

* It consists of one function:  
suppress ESU eligibility check for OS updates (including all .NET Framework updates)

______________________________

## Important Notes:

* Windows Powershell is required for this script to work

* Make sure that "Windows Management Instrumentation (winmgmt)" service is not disabled

* You can acquire and download the updates manually from Microsoft Update Catalog  
https://www.catalog.update.microsoft.com/Search.aspx?q=22H2+1903+Updates

to track the updates KB numbers, check the official Update History page  
https://support.microsoft.com/help/5018682

* Unless you integrate the ESU Suppressor, ESU updates are not supported offline for wim files  
you cannot integrate them, they must be installed online on a live system.

* If you used W10UI script, then it already install the same ESU Suppressor

* Extract the pack contents to a folder with simple path, example C:\files\BypassESU

* Temporarily turn off Antivirus protection (if any), or exclude the extracted folder

______________________________

## Bonus

* To get ESU updates though Windows Update for Windows 10 v22H2,  
add the following registry value using Command Prompt as administrator:

reg.exe add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\SoftwareProtectionPlatform\ESU" /v Win10CommercialW365ESUEligible /t REG_DWORD /d 1 /f

______________________________

## How to Use - Live OS Installation

* Install the recommended updates (reboot if required)

* right-click on LiveOS-Setup.cmd and "Run as administrator"  

* from the menu, press the corresponding number for the desired option

* Remarks:

ESU Suppressor should not be uninstalled after installing ESU updates

______________________________

## How to Use - Offline Image/Wim Integration

* Wim-Integration.cmd support two target types to integrate BypassESU:

[1] Direct WIM file (not mounted), either install.wim or boot.wim

[2] Already Mounted image directory, or offline image deployed on another partition/drive/vhd

___
** Direct WIM file integration **

- place install.wim or boot.wim (one of them, not both) next to Wim-Integration.cmd, then run the script as administrator

- alternatively, run the script as administrator, and when prompted, enter the full path for the wim file

- choose the desired option from the menu (similar to live setup)

- Notes about this method:  

it will also integrate the Suppressor for winre.wim, if it exists inside install.wim  

it does not provide options to remove the Suppressor, for that, mount the wim image then use second method

___
** Mounted directory / offline image integration **

- manually mount the image of install.wim or boot.wim  
no need for this step if the image is already deployed on another partition/drive/vhd, example Z:\

- No need to integrate the recommended updates, you can integrate BypassESU first

- right-click on Wim-Integration.cmd and "Run as administrator"

- enter the correct path for mounted directory or offline image drive letter

- choose the desired option from the menu (similar to live setup)

- afterwards, continue to integrate the updates, including ESU updates

- manually unmount install.wim/boot.wim image and commit changes

______________________________

## Credits

* asdcorp (haveSxS)
